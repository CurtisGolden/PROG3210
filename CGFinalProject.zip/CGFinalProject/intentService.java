package com.example.cgolden4241.cgmobileassignment1;

import android.app.IntentService;
import android.content.Intent;
import android.os.Looper;
import android.widget.Toast;
import android.os.Handler;


/**
 * Created by curtis on 2018-01-04.
 */

public class intentService extends IntentService {
    public intentService() {
        this(intentService.class.getName());
    }
    public intentService(String name) {
        super(name);
    }

    @Override
    protected void onHandleIntent(Intent intent) {
        showToast("Intent Service Started");
        try {
            Thread.sleep(15000);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        showToast("Intent Service Complete");
    }

    protected void showToast(final String msg){
        Handler handler = new Handler(Looper.getMainLooper());
        handler.post(new Runnable() {
            @Override
            public void run() {

                Toast.makeText(getApplicationContext(), msg, Toast.LENGTH_SHORT).show();
            }
        });
    }


}
