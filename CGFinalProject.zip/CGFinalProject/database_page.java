package com.example.cgolden4241.cgmobileassignment1;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;




public class database_page extends AppCompatActivity {

    Button button;
    SQLiteDatabase myDatabase;
    TextView txtdata;
    String Username;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setTitle("Database Management Page");
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_database_page);
        addListenerOnButton3();
        addListenerOnButton4();
        addListenerOnButton5();
    }


    public void addListenerOnButton4() {
        button = (Button) findViewById(R.id.btnCreateDatabase);

        button.setOnClickListener((new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    myDatabase = openOrCreateDatabase("appDatabase", MODE_PRIVATE, null);

                    Context context = getApplicationContext();
                    CharSequence text = "Database Creation Successful!";
                    int duration = Toast.LENGTH_SHORT;

                    Toast t = Toast.makeText(context, text, duration);
                    t.show();
                } catch(Exception ex) {
                    Context context = getApplicationContext();
                    CharSequence text = "Database Creation Unsuccessful!";
                    int duration = Toast.LENGTH_SHORT;

                    Toast t = Toast.makeText(context, text, duration);
                    t.show();
                }

            }
        }));
    }



    public void addListenerOnButton3() {
        button = (Button) findViewById(R.id.btnCreateTables);

        button.setOnClickListener((new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            try{
                myDatabase.execSQL("CREATE TABLE IF NOT EXISTS accountTable(Username VARCHAR,Password VARCHAR);");
                myDatabase.execSQL("CREATE TABLE IF NOT EXISTS dummyTable1(AltData VARCHAR);");
                myDatabase.execSQL("CREATE TABLE IF NOT EXISTS dummyTable2(AltData1 VARCHAR);");

                Context context = getApplicationContext();
                CharSequence text = "Table Creation Successful!";
                int duration = Toast.LENGTH_SHORT;

                Toast t = Toast.makeText(context, text, duration);
                t.show();
            } catch(Exception ex) {
                Context context = getApplicationContext();
                CharSequence text = "Table Creation Unsuccessful!";
                int duration = Toast.LENGTH_SHORT;

                Toast t = Toast.makeText(context, text, duration);
                t.show();
            }
            }
        }));
    }

    public void addListenerOnButton5() {
        button = (Button) findViewById(R.id.btnInsertData);



        button.setOnClickListener((new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                try{
                    myDatabase.execSQL("INSERT INTO accountTable (Username, Password) VALUES('admin','admin');");

                    Context context = getApplicationContext();
                    CharSequence text = "Insert Successful!";
                    int duration = Toast.LENGTH_SHORT;

                    Toast t = Toast.makeText(context, text, duration);
                    t.show();
                  /*    txtdata = (TextView)findViewById(R.id.txtData);
                    Cursor UserN = myDatabase.rawQuery("SELECT Username FROM accountTable",null);
                    Username = UserN.getString(UserN.getColumnIndex(0));
                    //Cursor Pass = myDatabase.rawQuery("SELECT Password FROM accountTable",null);
                    //String password = Pass.getString(1);
                    txtdata.setText(Username);
                    */

                } catch(Exception ex) {
                    Context context = getApplicationContext();
                    CharSequence text = "Insert Unsuccessful!";
                    int duration = Toast.LENGTH_SHORT;

                    Toast t = Toast.makeText(context, text, duration);
                    t.show();

                }


            }
        }));
     //   mServiceIntent = new Intent(getActivity(), backgroundService.class);
     //   mServiceIntent.setData(Uri.parse(dataUrl));

    }




}
//hello team
//i am doing my best
