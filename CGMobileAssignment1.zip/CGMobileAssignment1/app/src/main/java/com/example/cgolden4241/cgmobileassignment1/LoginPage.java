package com.example.cgolden4241.cgmobileassignment1;

import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.view.View;
import android.widget.Toast;
import android.view.View.OnClickListener;

public class LoginPage extends AppCompatActivity {

    Button button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setTitle("Log In Page");
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_page);
        addListenerOnButton3();
    }

    public void addListenerOnButton3() {
        button = (Button)findViewById(R.id.btnLogIn1);

        button.setOnClickListener((new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Context context = getApplicationContext();
                CharSequence text = "Log In Unsuccessful!";
                int duration = Toast.LENGTH_SHORT;

                Toast t = Toast.makeText(context, text, duration);
                t.show();
            }
        }));
    }
}
