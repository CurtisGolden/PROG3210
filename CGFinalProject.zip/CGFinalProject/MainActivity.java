package com.example.cgolden4241.cgmobileassignment1;

import android.app.IntentService;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.content.Intent;
import android.content.Context;
import android.view.View.OnClickListener;


public class MainActivity extends AppCompatActivity {


    Button button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setTitle("Home");
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        addListenerOnButton();
        addListenerOnButton1();
        addListenerOnButton4();
        addListenerOnButton5();
        addListenerOnButton6();
        addListenerOnButton7();
        launchService();
    }


    public void addListenerOnButton() {

        final Context context = this;

        button = (Button)findViewById(R.id.btnLogIn);

        button.setOnClickListener((new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(context, LoginPage.class);
                        startActivity(intent);
            }
        }));


    }
    public void addListenerOnButton1() {

        final Context context = this;

        button = (Button)findViewById(R.id.btnRegister);

        button.setOnClickListener((new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(context, RegistrationPage.class);
                startActivity(intent);
            }
        }));
    }
    public void addListenerOnButton4() {

        final Context context = this;

        button = (Button)findViewById(R.id.btnDatabase);

        button.setOnClickListener((new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(context, database_page.class);
                startActivity(intent);
            }
        }));
    }
    public void addListenerOnButton5() {

        final Context context = this;

        button = (Button)findViewById(R.id.btnAbout);

        button.setOnClickListener((new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(context, AboutPage.class);
                startActivity(intent);
            }
        }));
    }
    public void addListenerOnButton6() {

        final Context context = this;

        button = (Button)findViewById(R.id.btnNews);

        button.setOnClickListener((new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(context, newsFeed.class);
                startActivity(intent);
            }
        }));
    }

    public void addListenerOnButton7() {

        final Context context = this;

        button = (Button)findViewById(R.id.btnLists);

        button.setOnClickListener((new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(context, listActivity.class);
                startActivity(intent);
            }
        }));
    }

    public void launchService() {
        Intent i = new Intent(this, intentService.class);

        startService(i);
    }


}
