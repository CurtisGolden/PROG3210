package com.example.cgolden4241.cgmobileassignment1;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;
import android.app.Activity;

public class listActivity extends Activity {
    ListView Items;
    Integer[] imageId = {
            R.drawable.whip,
            R.drawable.ags,
            R.drawable.dds,
            R.drawable.dscim,
            R.drawable.dfs

    };
    String[] web = {
            "Abyssal Whip",
            "Armadyl Godsword",
            "Dragon Dagger (p++)",
            "Dragon Scimitar",
            "Dragonfire Shield"
    } ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setTitle("Lists");
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);
        listManager listAdapter = new
                listManager(listActivity.this, web, imageId);
        Items=(ListView)findViewById(R.id.list);
        Items.setAdapter(listAdapter);
        Items.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view,
                                    int position, long id) {
                Toast.makeText(listActivity.this, "You selected " +web[+ position], Toast.LENGTH_SHORT).show();
            }
        });
    }
}