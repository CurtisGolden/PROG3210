package com.example.cgolden4241.cgmobileassignment1;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.app.Activity;
import android.content.Context;
import android.widget.Toast;
import android.os.AsyncTask;
import java.net.URL;

public class newsFeed extends AppCompatActivity {

    private static String URL_STRING = "http://Runescape.com";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setTitle("Async");
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_news_feed);

        new DownloadFeed().execute(URL_STRING);
    }

    class DownloadFeed extends AsyncTask<String, Void, String> {
        @Override
        protected String doInBackground(String... params) {
            String urlString = params[0];
            String test = "Success";
            return "Async test: " + test;
        }

        @Override
        protected void onPostExecute(String result) {
            Context context = newsFeed.this;
            Toast.makeText(context, result, Toast.LENGTH_LONG).show();
        }


    }
}
