package com.example.cgolden4241.cgmobileassignment1;

import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;
import android.view.View.OnClickListener;

public class RegistrationPage extends AppCompatActivity {

    Button button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setTitle("Registration Page");
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration_page);
        addListenerOnButton2();
    }


    public void addListenerOnButton2() {

        button = (Button)findViewById(R.id.btnRegister1);

        button.setOnClickListener((new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Context context = getApplicationContext();
                CharSequence text = "Registration Unsuccessful!";
                int duration = Toast.LENGTH_SHORT;

                Toast t = Toast.makeText(context, text, duration);
                t.show();
            }
        }));
    }





}