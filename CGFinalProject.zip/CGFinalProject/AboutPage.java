package com.example.cgolden4241.cgmobileassignment1;

import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.content.Context;
import android.content.Intent;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;
import android.view.View.OnClickListener;

public class AboutPage extends AppCompatActivity {

    Button button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setTitle("About");
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about_page);
        addListenerOnButton3();
        addListenerOnButton4();
    }

    public void addListenerOnButton3() {

        button = (Button) findViewById(R.id.btnPhone);

        button.setOnClickListener((new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Context context = getApplicationContext();

                Intent intent = new Intent(Intent.ACTION_DIAL);
                startActivity(intent);
            }
        }));

    }


    public void addListenerOnButton4() {

        button = (Button) findViewById(R.id.btnEmail);

        button.setOnClickListener((new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Context context = getApplicationContext();

                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse("sms:"));
                startActivity(intent);
            }
        }));
    }
}
