package com.example.cgolden4241.cgmobileassignment1;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.content.Intent;
import android.content.Context;
import android.view.View.OnClickListener;


public class MainActivity extends AppCompatActivity {


    Button button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setTitle("Home");
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        addListenerOnButton();
        addListenerOnButton1();
    }


    public void addListenerOnButton() {

        final Context context = this;

        button = (Button)findViewById(R.id.btnLogIn);

        button.setOnClickListener((new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(context, LoginPage.class);
                        startActivity(intent);
            }
        }));


    }
    public void addListenerOnButton1() {

        final Context context = this;

        button = (Button)findViewById(R.id.btnRegister);

        button.setOnClickListener((new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(context, RegistrationPage.class);
                startActivity(intent);
            }
        }));
    }
}
